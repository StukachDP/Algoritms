package com.company.SortAlgoritms;

public class Main {
        public static void main(String[] args) {

            int elementNumber = (int) Math.pow(2,17);
            int elementNumberLess = (int) Math.pow(2,8);

            int[] arrayUsual = new int[elementNumber];
            for (int i = 0; i < arrayUsual.length; i++) {
                arrayUsual[i] = (int)(Math.random()*elementNumber + 1);
            }

            int[] arrayAlmostSort = new int[elementNumber];
            for (int i = 0; i < arrayAlmostSort.length; i++) {
                arrayAlmostSort[i] = i;
            }
            arrayAlmostSort[3] = 7;
            arrayAlmostSort[elementNumber - 34] = 567;
            arrayAlmostSort[7] = 1;


            int[] arrayLessUsual = new int[elementNumberLess];
            for (int i = 0; i < arrayLessUsual.length; i++) {
                arrayLessUsual[i] = (int)(Math.random() * elementNumberLess + 1);
            }

            int[] arraySmallScopeElements = new int[elementNumberLess];
            for (int i = 0; i < arraySmallScopeElements.length; i++) {
                arraySmallScopeElements[i] = (int)(Math.random() * 2);
            }

//            for (int i = 0; i < arrayUsual.length - 1; i++) {
//                for (int j = 0; j < arrayUsual.length - i - 1; j++) {
//                    if (arrayUsual[j] > arrayUsual[j+1]){
//                        int promResult = arrayUsual[j];
//                        arrayUsual[j] = arrayUsual[j+1];
//                        arrayUsual[j+1] = promResult;
//                    }
//                }
//            }

            long startTime = System.currentTimeMillis();

//            Algoritms.bubbleSort(arraySmallScopeElements);
            Algoritms.insertSort(arrayUsual);
//            Algoritms.quickSort(arraySmallScopeElements,0,elementNumberLess-1);
//            Algoritms.mergeSort(arraySmallScopeElements,0,elementNumberLess-1);
//            Algoritms.gibridSort(arraySmallScopeElements);
//            Algoritms.scoopSort(arraySmallScopeElements);



            for (int i = 0; i < arrayUsual.length; i++) {
                System.out.println(arrayUsual[i]);
            }

            long timeSpent = System.currentTimeMillis() - startTime;
            System.out.println("программа выполнялась " + timeSpent + " миллисекунд");
        }
}
