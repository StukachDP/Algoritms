package com.company.SortAlgoritms;

public class Algoritms {

    //FOR MERGE SORT
    private static void merge(int[] array, int start, int middle, int end)
    {
        // Find sizes of two subarrays to be merged
        int leftSize = middle - start + 1;
        int rightSize = end - middle;

        /* Create temp arrays */
        int[] leftSubArray = new int[leftSize];
        int[] rightSubArray = new int[rightSize];

        /*Copy data to temp arrays*/
        for (int i = 0; i < leftSize; ++i)
            leftSubArray[i] = array[start + i];
        for (int j = 0; j < rightSize; ++j)
            rightSubArray[j] = array[middle + 1 + j];

        /* Merge the temp arrays */

        // Initial indexes of first and second subarrays
        int leftConter = 0, rightCounter = 0;

        // Initial index of merged subarry array
        int k = start;
        while (leftConter < leftSize && rightCounter < rightSize) {
            if (leftSubArray[leftConter] <= rightSubArray[rightCounter]) {
                array[k] = leftSubArray[leftConter];
                leftConter++;
            }
            else {
                array[k] = rightSubArray[rightCounter];
                rightCounter++;
            }
            k++;
        }

        /* Copy remaining elements of L[] if any */
        while (leftConter < leftSize) {
            array[k] = leftSubArray[leftConter];
            leftConter++;
            k++;
        }

        /* Copy remaining elements of R[] if any */
        while (rightCounter < rightSize) {
            array[k] = rightSubArray[rightCounter];
            rightCounter++;
            k++;
        }
    }

    //FOR QUICK SORT
    private  static int partition(int[] array, int low, int high)
    {
        int pivot = array[high];
        int i = (low-1); // index of smaller element
        for (int j=low; j<high; j++)
        {
            // If current element is smaller than the pivot
            if (array[j] < pivot)
            {
                i++;

                // swap arr[i] and arr[j]
                int temp = array[i];
                array[i] = array[j];
                array[j] = temp;
            }
        }

        // swap arr[i+1] and arr[high] (or pivot)
        int temp = array[i+1];
        array[i+1] = array[high];
        array[high] = temp;

        return i+1;
    }

    //FOR HYBRID SORT
    private static int getNextGap(int gap)
    {
        // Shrink gap by Shrink factor
        gap = (gap*10)/13;
        if (gap < 1)
            return 1;
        return gap;
    }


    //SORTING ALGORITMS

    public static void bubbleSort(int[] array){
        for (int i = 0; i < array.length - 1; i++) {
            for (int j = 0; j < array.length - i - 1; j++) {
                if (array[j] > array[j+1]){
                    int partResult = array[j];
                    array[j] = array[j+1];
                    array[j+1] = partResult;
                }
            }
        }
    }


    public static int[] insertSort(int[] array){
        for (int i = 1; i < array.length; ++i) {
            int key = array[i];
            int j = i - 1;

            while (j >= 0 && array[j] > key) {
                array[j + 1] = array[j];
                j = j - 1;
            }
            array[j + 1] = key;
        }
        return array;
    }


    public static void quickSort(int[] array, int low, int high){
        if (low < high)
        {
            /* pi is partitioning index, arr[pi] is
              now at right place */
            int pi = partition(array, low, high);

            // Recursively sort elements before
            // partition and after partition
            quickSort(array, low, pi-1);
            quickSort(array, pi+1, high);
        }
    }


    public static void mergeSort(int[] array, int start, int end){
        if (start < end) {
            // Find the middle point
            int middle = (start + end) / 2;

            // Sort first and second halves
            mergeSort(array, start, middle);
            mergeSort(array, middle + 1, end);

            // Merge the sorted halves
            merge(array, start, middle, end);
        }
    }


    public static void gibridSort(int[] array){
        int n = array.length;

        // initialize gap
        int gap = n;

        // Initialize swapped as true to make sure that
        // loop runs
        boolean swapped = true;

        // Keep running while gap is more than 1 and last
        // iteration caused a swap
        while (gap != 1 || swapped)
        {
            // Find next gap
            gap = getNextGap(gap);

            // Initialize swapped as false so that we can
            // check if swap happened or not
            swapped = false;

            // Compare all elements with current gap
            for (int i = 0; i < n-gap; i++)
            {
                if (array[i] > array[i+gap])
                {
                    // Swap arr[i] and arr[i+gap]
                    int partRes = array[i];
                    array[i] =  array[i+gap];
                    array[i+gap] = partRes;

                    // Set swapped
                    swapped = true;
                }
            }
        }
    }

    public static void scoopSort(int[] array) {
        int n = array.length;

        // The output character array that will have sorted arr
        int[] output = new int[n];

        // Create a count array to store count of inidividul
        // characters and initialize count array as 0
        int[] count = new int[n];
        for (int i = 0; i < n; i++){
            count[i] = 0;
        }

        // store count of each character
        for (int i = 0; i < n; ++i){
            ++count[array[i]];
        }

        // Change count[i] so that count[i] now contains actual
        // position of this character in output array
        for (int i = 1; i <= n-1; ++i){
            count[i] += count[i - 1];
        }

        // Build the output character array
        // To make it stable we are operating in reverse order.
        for (int i = n - 1; i >= 0; i--) {
            output[count[array[i]] - 1] = array[i];
            --count[array[i]];
        }
        // Copy the output array to arr, so that arr now
        // contains sorted characters
        for (int i = 0; i < n; ++i) {
            array[i] = output[i];
        }
    }

}
