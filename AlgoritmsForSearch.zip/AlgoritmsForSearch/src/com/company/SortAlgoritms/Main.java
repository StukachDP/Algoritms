package com.company.SortAlgoritms;

public class Main {
        public static void main(String[] args) {

//            int elementNumber = (int) Math.pow(2,17);
//            int elementNumberLess = (int) Math.pow(2,8);
            int searchArraySize = (int) Math.pow(2, 20);

            int[] arrayForSearch = new int[searchArraySize];
            for (int i = 0; i < searchArraySize; i++) {
                arrayForSearch[i] = i;
            }

            // STUPIDITY TO BE ABLE TO SORT.
            arrayForSearch[0] = 101;
            arrayForSearch[100] = 0;
            arrayForSearch[101] = 100;
            arrayForSearch[searchArraySize - 1] = searchArraySize - 10;
            arrayForSearch[searchArraySize - 10] = searchArraySize - 1;
            arrayForSearch[10] = searchArraySize;
            // ENOUGH NONSENSE

//            int[] arrayUsual = new int[elementNumber];
//            for (int i = 0; i < arrayUsual.length; i++) {
//                arrayUsual[i] = (int)(Math.random()*elementNumber + 1);
//            }
//
//            int[] arrayAlmostSort = new int[elementNumber];
//            for (int i = 0; i < arrayAlmostSort.length; i++) {
//                arrayAlmostSort[i] = i;
//            }
//            arrayAlmostSort[3] = 7;
//            arrayAlmostSort[elementNumber - 34] = 567;
//            arrayAlmostSort[7] = 1;
//
//
//            int[] arrayLessUsual = new int[elementNumberLess];
//            for (int i = 0; i < arrayLessUsual.length; i++) {
//                arrayLessUsual[i] = (int)(Math.random() * elementNumberLess + 1);
//            }
//
//            int[] arraySmallScopeElements = new int[elementNumberLess];
//            for (int i = 0; i < arraySmallScopeElements.length; i++) {
//                arraySmallScopeElements[i] = (int)(Math.random() * 2);
//            }
//            Algoritms.bubbleSort(arraySmallScopeElements);
//            Algoritms.insertSort(arrayUsual);
//            Algoritms.quickSort(arraySmallScopeElements,0,elementNumberLess-1);
//            Algoritms.mergeSort(arraySmallScopeElements,0,elementNumberLess-1);
//            Algoritms.gibridSort(arraySmallScopeElements);
//            Algoritms.scoopSort(arrayUsual);

            long startTime = System.currentTimeMillis();

            //SEARCH ELEMENT IN ARRAY
            int numberForSearch = 1049;
//            Algoritms.mergeSort(arrayForSearch, 0, arrayForSearch.length - 1);
//            int positionInArray = SearchAlgoritms.sequentialSearch(arrayForSearch, numberForSearch);
//            int positionInArray = SearchAlgoritms.binarySearch(arrayForSearch, numberForSearch);
            int positionInArray = SearchAlgoritms.interpolationSearch(arrayForSearch, numberForSearch);
            if (positionInArray != -1){
                System.out.println("Position of your number is: " + positionInArray);
            }
            else{
                System.out.println("No this number in array");
            }

            long timeSpent = System.currentTimeMillis() - startTime;
            System.out.println("программа выполнялась " + timeSpent + " миллисекунд");
        }
}
