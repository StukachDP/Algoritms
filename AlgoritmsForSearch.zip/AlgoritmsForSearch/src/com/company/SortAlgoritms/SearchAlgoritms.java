package com.company.SortAlgoritms;

public class SearchAlgoritms {

    public static int sequentialSearch(int[] array, int searchNumber){
        int arraySearchIndex = -1;
        for (int i = 0; i < array.length; i++) {
            if (array[i] == searchNumber){
                arraySearchIndex = i;
            }
        }
        return arraySearchIndex;
    }


    public static int binarySearch(int[] array, int searchNumber){
        int arraySearchIndex = -1;
        int firstIndex = 0;
        int lastIndex = array.length - 1;

        while(firstIndex <= lastIndex) {
            int middleIndex = (firstIndex + lastIndex) / 2;
            if (array[middleIndex] == searchNumber) {
                arraySearchIndex = middleIndex;
                return arraySearchIndex;
            }
            else if (array[middleIndex] < searchNumber){
                firstIndex = middleIndex + 1;
            }
            else if (array[middleIndex] > searchNumber){
                lastIndex = middleIndex - 1;
            }

        }
        return arraySearchIndex;
    }

    public static int interpolationSearch(int[] array, int searchNumber){
        int arraySearchIndex = -1;
        int firstIndex = 0;
        int endIndex = (array.length - 1);

        while ((firstIndex <= endIndex) &&
                (searchNumber >= array[firstIndex]) &&
                (searchNumber <= array[endIndex]))
        {
            int interpolatePosition = firstIndex +
                    (endIndex - firstIndex) /
                    (array[endIndex] - array[firstIndex]) *
                    (searchNumber - array[firstIndex]);


            if (array[interpolatePosition] == searchNumber){
                arraySearchIndex = interpolatePosition;
                return arraySearchIndex;
            }

            if (array[interpolatePosition] < searchNumber){
                firstIndex = interpolatePosition + 1;
            }
            else{
                endIndex = interpolatePosition - 1;
            }
        }
        return arraySearchIndex;
    }
}
